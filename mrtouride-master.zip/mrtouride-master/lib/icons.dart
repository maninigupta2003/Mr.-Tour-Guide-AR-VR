import 'package:flutter/material.dart';

const loginbg = 'assets/bg.svg';